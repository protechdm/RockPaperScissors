﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace RockPaperScissorGame
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private RPSGame _rpsGame;
        private void Form1_Load(object sender, EventArgs e)
        {
            _rpsGame = new RPSGame();
        }


        private void SetImages(RPSEventArgs args)
        {
            panelPlayer.BackColor = Color.Cornsilk;
            panelOpponent.BackColor = Color.Cornsilk;
            SetImage(ChallengerPictureBox, args.ChallengerObjectChosen);
            SetImage(OpponentPictureBox, args.OpponentObjectChosen);
        }

        private void SetImage(PictureBox pictureBox, ObjectChosen objectChosen)
        {
            switch (objectChosen)
            {
                case ObjectChosen.Rock:
                    pictureBox.Image = rockPicturebox.Image;
                    break;
                case ObjectChosen.Paper:
                    pictureBox.Image = paperPicturebox.Image;
                    break;
                case ObjectChosen.Scissors:
                    pictureBox.Image = scissorsPictureBox.Image;
                    break;
            }
        }
        private void btnClear_Click(object sender, EventArgs e)
        {
            // Clearing the images
            OpponentPictureBox.Image = null;
            ChallengerPictureBox.Image = null;
            panelPlayer.BackColor = Color.LightGray;
            panelOpponent.BackColor = Color.LightGray;
        }

        private void rockPicturebox_Click(object sender, EventArgs e)
        {
            RPSEventArgs args = new RPSEventArgs(ObjectChosen.Rock, (ObjectChosen)(_rpsGame.GetRandomNumber()));
            SetImages(args);
            MessageBox.Show(_rpsGame.PlayGame(args).ToString());
        }

        private void paperPicturebox_Click(object sender, EventArgs e)
        {
            RPSEventArgs args = new RPSEventArgs(ObjectChosen.Paper, (ObjectChosen)(_rpsGame.GetRandomNumber()));
            SetImages(args);
            MessageBox.Show(_rpsGame.PlayGame(args).ToString());
        }

        private void scissorsPictureBox_Click(object sender, EventArgs e)
        {
            RPSEventArgs args = new RPSEventArgs(ObjectChosen.Scissors, (ObjectChosen)(_rpsGame.GetRandomNumber()));
            SetImages(args);
            MessageBox.Show(_rpsGame.PlayGame(args).ToString());
        }

        private void btnComputerVComputer_Click(object sender, EventArgs e)
        {
            RPSEventArgs args = new RPSEventArgs((ObjectChosen)(_rpsGame.GetRandomNumber()), (ObjectChosen)(_rpsGame.GetRandomNumber()));
            SetImages(args);
            MessageBox.Show(_rpsGame.PlayGame(args).ToString());
        }
    }

}
