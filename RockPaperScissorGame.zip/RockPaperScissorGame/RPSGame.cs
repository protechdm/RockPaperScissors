﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RockPaperScissorGame
{
    public class RPSGame
    {
        public GameOutcome PlayGame(RPSEventArgs e)
        {
            GameOutcome gameOutcome = GameOutcome.NoResult;
            try
            {

                ObjectChosen challengerChoice = e.ChallengerObjectChosen;
                ObjectChosen opponentChoice = e.OpponentObjectChosen;

                if (challengerChoice == opponentChoice)
                {
                    gameOutcome = GameOutcome.Tie;
                }
                else if
                    (challengerChoice == ObjectChosen.Rock && opponentChoice == ObjectChosen.Scissors
                    ||
                    challengerChoice == ObjectChosen.Paper && opponentChoice == ObjectChosen.Rock
                    ||
                    challengerChoice == ObjectChosen.Scissors && opponentChoice == ObjectChosen.Paper
                    )
                {
                    gameOutcome = GameOutcome.ChallengerWins;
                }
                else
                {
                    gameOutcome = GameOutcome.OpponentWins;
                }
            }
            catch (Exception ex)
            {

            }
            return gameOutcome;
        }

        public int GetRandomNumber()
        {
            System.Threading.Thread.Sleep(100);
            return (new Random().Next(1, 400000000) % 3) +1;
        }


    }

    public class RPSEventArgs : EventArgs
    {
        public ObjectChosen ChallengerObjectChosen { get; }
        public ObjectChosen OpponentObjectChosen { get; }
        public RPSEventArgs(ObjectChosen challengerObjectChosen, ObjectChosen opponentObjectChosen)
        {
            ChallengerObjectChosen = challengerObjectChosen;
            OpponentObjectChosen = opponentObjectChosen;
        }
    }

    public enum ObjectChosen
    {
        Rock = 1,
        Paper = 2,
        Scissors = 3
    }

    public enum GameOutcome
    {
        ChallengerWins = 1,
        Tie = 2,
        OpponentWins = 3,
        NoResult = 4
    }

    public enum Challenger
    {
        Human = 1,
        Computer = 2
    }

}
