﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RockPaperScissorGame;

namespace UnitTestRockPaperScissors
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Tie()
        {
            RPSGame game = new RPSGame();
            RPSEventArgs args = new RPSEventArgs(ObjectChosen.Paper, ObjectChosen.Paper);
            Assert.IsTrue(game.PlayGame(args) == GameOutcome.Tie);
        }

        [TestMethod]
        public void NoArguments()
        {
            RPSGame game = new RPSGame();
            Assert.IsTrue(game.PlayGame(null) == GameOutcome.NoResult);
        }

        [TestMethod]
        public void ChallengerWins()
        {
            RPSGame game = new RPSGame();
            RPSEventArgs args = new RPSEventArgs(ObjectChosen.Paper, ObjectChosen.Rock);
            Assert.IsTrue(game.PlayGame(args) == GameOutcome.ChallengerWins);
        }

        [TestMethod]
        public void OpponentWins()
        {
            RPSGame game = new RPSGame();
            RPSEventArgs args = new RPSEventArgs(ObjectChosen.Paper, ObjectChosen.Scissors);
            Assert.IsTrue(game.PlayGame(args) == GameOutcome.OpponentWins);
        }

        [TestMethod]
        public void RandomNumberIsBetween1And4()
        {
            RPSGame game = new RPSGame();
            var randomNumber = game.GetRandomNumber();
            Assert.IsTrue(randomNumber > 0 && randomNumber <=4);
        }

    }
}
